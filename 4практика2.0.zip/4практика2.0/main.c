#include <8051.h>  
void msec (int x)  
{ 
	while(x-->0) 
	{ 
		TH0 = (-10000)>>8;
		TL0=-10000;
		TR0=1; 
 
		do; 
		while(TF0==0);  
		TF0=0;  
		TR0=0;  
	} 
}

void main()  
{ 
	int i; 
	unsigned char array[5] = {0x0, 0b00000011, 0b11000000, 0b00001100,  0b00110000}; 
	TMOD=0x1;  
	P1=array[0];
	msec(200); 
	for(i=1;i<5;i++) 
	{
		P1=array[i];
		if (i<2)msec(200);
		else msec(500);  

	} 
	while(1); 
} 